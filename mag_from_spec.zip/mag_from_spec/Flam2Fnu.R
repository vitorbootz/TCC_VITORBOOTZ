rm(list = ls())
t = read.table('./IRAF/G10_z00.cxt')
lz = t$V1 * 1.0551521
#fnu = t$V2 * (t$V1**2 * 1e-8) / 2.99792e10 * 1e26 * 10e-17
fmjy = t$V2 * lz**2 * 3.34e7 * 1e-17
plot(lz, fmjy, type = 'l')
data <- sprintf('%8.2f%20.5f', lz, fmjy)
write(data, file = './IRAF/G10_FmJy.cxt')


flam = t$V2 * 1e-17
data <- sprintf('%8.2f%20.5e', lz, flam)
write(data, file = './IRAF/G10_Flam.cxt')

flam = t$V2
data <- sprintf('%8.2f%20.5e', lz, flam)
write(data, file = './IRAF/G10_z05.cxt')

fnu = fmjy * 1e26
plot(lz, fnu, type = 'l')
data <- sprintf('%8.2f%20.5e', lz, fnu)
write(data, file = './IRAF/G10_Fnu.cxt')


